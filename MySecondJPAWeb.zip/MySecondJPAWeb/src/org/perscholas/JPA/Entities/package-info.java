/**
 * 
 */
/**
 * @author Stefanski
 *
 */
package org.perscholas.JPA.Entities;